from .rectangulo import Rectangulo
from .cuadrado import Cuadrado
