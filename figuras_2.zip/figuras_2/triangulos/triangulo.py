import math

from figuras_2.bases.figura import Figura

class Triangulo(Figura):
    def __init__(self, vertices, bordes, es_regular):
        super().__init__(vertices, bordes, es_regular)

    def calcular_angulos_internos(self):
        if len(self.get_vertices()) == 3:
            a = self.get_bordes()[0].get_longitud()
            b = self.get_bordes()[1].get_longitud()
            c = self.get_bordes()[2].get_longitud()
            angulo_A = math.degrees(math.acos((b**2 + c**2 - a**2) / 
                                              (2 * b * c)))
            angulo_B = math.degrees(math.acos((a**2 + c**2 - b**2) / 
                                              (2 * a * c)))
            angulo_C = 180 - angulo_A - angulo_B
            return [angulo_A, angulo_B, angulo_C]
        else:
            return []

    def calcular_area(self):
        pass
