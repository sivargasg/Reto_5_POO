from .triangulo import Triangulo
from .isosceles import Isosceles
from .equilatero import Equilatero
from .escaleno import Escaleno
from .trirectangulo import TriRectangulo
