import math

from .triangulo import Triangulo
from figuras_2.bases.punto import Punto
from figuras_2.bases.linea import Linea


class Equilatero(Triangulo):
    def __init__(self, lado):
        altura = (math.sqrt(3) / 2) * lado
        vertices = [Punto(0, 0), Punto(lado, 0), Punto(lado / 2, altura)]
        bordes = [Linea(vertices[0], vertices[1]),
                  Linea(vertices[1], vertices[2]),
                  Linea(vertices[2], vertices[0])]
        super().__init__(vertices, bordes, es_regular=True)
        self.__lado = lado

    def get_lado(self):
        return self.__lado

    def set_lado(self, lado):
        self.__lado = lado

    def calcular_area(self):
        return (math.sqrt(3) / 4) * self.__lado ** 2

    def calcular_angulos_internos(self):
        return [60, 60, 60]
