from .punto import Punto

class Linea:
    def __init__(self, punto_inicio, punto_fin):
        self.__punto_inicio = punto_inicio
        self.__punto_fin = punto_fin
        self.__longitud = self.calcular_longitud()

    def get_punto_inicio(self):
        return self.__punto_inicio

    def set_punto_inicio(self, punto_inicio):
        self.__punto_inicio = punto_inicio

    def get_punto_fin(self):
        return self.__punto_fin

    def set_punto_fin(self, punto_fin):
        self.__punto_fin = punto_fin

    def get_longitud(self):
        return self.__longitud

    def calcular_longitud(self):
        return self.__punto_inicio.calcular_distancia(self.__punto_fin)