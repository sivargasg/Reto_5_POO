class Punto:
    def __init__(self, x, y):
        self.__x = x
        self.__y = y

    def get_x(self):
        return self.__x

    def set_x(self, x):
        self.__x = x

    def get_y(self):
        return self.__y

    def set_y(self, y):
        self.__y = y

    def calcular_distancia(self, otro_punto):
        return ((self.__x - otro_punto.get_x()) ** 2 + (
            self.__y - otro_punto.get_y()) ** 2)**0.5