from .punto import Punto
from .linea import Linea
from .figura import Figura