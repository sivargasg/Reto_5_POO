import math

class Punto:
    def __init__(self, x, y):
        self.__x = x
        self.__y = y

    def get_x(self):
        return self.__x

    def set_x(self, x):
        self.__x = x

    def get_y(self):
        return self.__y

    def set_y(self, y):
        self.__y = y

    def calcular_distancia(self, otro_punto):
        return math.sqrt((self.__x - otro_punto.get_x()) ** 2 + (self.__y - otro_punto.get_y()) ** 2)

class Linea:
    def __init__(self, punto_inicio, punto_fin):
        self.__punto_inicio = punto_inicio
        self.__punto_fin = punto_fin
        self.__longitud = self.calcular_longitud()

    def get_punto_inicio(self):
        return self.__punto_inicio

    def set_punto_inicio(self, punto_inicio):
        self.__punto_inicio = punto_inicio

    def get_punto_fin(self):
        return self.__punto_fin

    def set_punto_fin(self, punto_fin):
        self.__punto_fin = punto_fin

    def get_longitud(self):
        return self.__longitud

    def calcular_longitud(self):
        return self.__punto_inicio.calcular_distancia(self.__punto_fin)

class Figura:
    def __init__(self, vertices, bordes, es_regular):
        self.__vertices = vertices
        self.__bordes = bordes
        self.__es_regular = es_regular
        self.__angulos_internos = []

    def get_vertices(self):
        return self.__vertices

    def set_vertices(self, vertices):
        self.__vertices = vertices

    def get_bordes(self):
        return self.__bordes

    def set_bordes(self, bordes):
        self.__bordes = bordes

    def get_es_regular(self):
        return self.__es_regular

    def set_es_regular(self, es_regular):
        self.__es_regular = es_regular

    def get_angulos_internos(self):
        return self.__angulos_internos

    def set_angulos_internos(self, angulos_internos):
        self.__angulos_internos = angulos_internos

    def calcular_area(self):
        pass

    def calcular_perimetro(self):
        pass

    def calcular_angulos_internos(self):
        if self.__es_regular and len(self.__vertices) > 2:
            angulo = (len(self.__vertices) - 2) * 180 / len(self.__vertices)
            return [angulo] * len(self.__vertices)
        else:
            return []

class Triangulo(Figura):
    def __init__(self, vertices, bordes, es_regular):
        super().__init__(vertices, bordes, es_regular)

    def calcular_angulos_internos(self):
        if len(self.get_vertices()) == 3:
            a = self.get_bordes()[0].get_longitud()
            b = self.get_bordes()[1].get_longitud()
            c = self.get_bordes()[2].get_longitud()
            angulo_A = math.degrees(math.acos((b**2 + c**2 - a**2) / (2 * b * c)))
            angulo_B = math.degrees(math.acos((a**2 + c**2 - b**2) / (2 * a * c)))
            angulo_C = 180 - angulo_A - angulo_B
            return [angulo_A, angulo_B, angulo_C]
        else:
            return []

    def calcular_area(self):
        pass

class Isosceles(Triangulo):
    def __init__(self, base, altura):
        vertices = [Punto(0, 0), Punto(base / 2, altura), Punto(base, 0)]
        bordes = [Linea(vertices[0], vertices[1]), Linea(vertices[1], vertices[2]), Linea(vertices[2], vertices[0])]
        super().__init__(vertices, bordes, es_regular=False)
        self.__base = base
        self.__altura = altura

    def get_base(self):
        return self.__base

    def set_base(self, base):
        self.__base = base

    def get_altura(self):
        return self.__altura

    def set_altura(self, altura):
        self.__altura = altura

    def calcular_area(self):
        return (self.__base * self.__altura) / 2

class Equilatero(Triangulo):
    def __init__(self, lado):
        altura = (math.sqrt(3) / 2) * lado
        vertices = [Punto(0, 0), Punto(lado, 0), Punto(lado / 2, altura)]
        bordes = [Linea(vertices[0], vertices[1]), Linea(vertices[1], vertices[2]), Linea(vertices[2], vertices[0])]
        super().__init__(vertices, bordes, es_regular=True)
        self.__lado = lado

    def get_lado(self):
        return self.__lado

    def set_lado(self, lado):
        self.__lado = lado

    def calcular_area(self):
        return (math.sqrt(3) / 4) * self.__lado ** 2

    def calcular_angulos_internos(self):
        return [60, 60, 60]

class Escaleno(Triangulo):
    def __init__(self, base, altura):
        vertices = [Punto(0, 0), Punto(base, 0), Punto(base / 2, altura)]
        bordes = [Linea(vertices[0], vertices[1]), Linea(vertices[1], vertices[2]), Linea(vertices[2], vertices[0])]
        super().__init__(vertices, bordes, es_regular=False)
        self.__base = base
        self.__altura = altura

    def get_base(self):
        return self.__base

    def set_base(self, base):
        self.__base = base

    def get_altura(self):
        return self.__altura

    def set_altura(self, altura):
        self.__altura = altura

    def calcular_area(self):
        return (self.__base * self.__altura) / 2

class TriRectangulo(Triangulo):
    def __init__(self, base, altura):
        self.__base = base
        self.__altura = altura
        vertices = [Punto(0, 0), Punto(base, 0), Punto(0, altura)]
        bordes = [Linea(vertices[0], vertices[1]), Linea(vertices[1], vertices[2]), Linea(vertices[2], vertices[0])]
        super().__init__(vertices, bordes, es_regular=False)
        self.set_angulos_internos(self.calcular_angulos_internos())

    def get_base(self):
        return self.__base

    def set_base(self, base):
        self.__base = base

    def get_altura(self):
        return self.__altura

    def set_altura(self, altura):
        self.__altura = altura

    def calcular_area(self):
        return (self.__base * self.__altura) / 2

    def calcular_angulos_internos(self):
        return [90, math.degrees(math.atan(self.__altura / self.__base)), 90 - math.degrees(math.atan(self.__altura / self.__base))]

class Rectangulo(Figura):
    def __init__(self, ancho, alto):
        vertices = [Punto(0, 0), Punto(ancho, 0), Punto(ancho, alto), Punto(0, alto)]
        bordes = [Linea(vertices[0], vertices[1]), Linea(vertices[1], vertices[2]), Linea(vertices[2], vertices[3]), Linea(vertices[3], vertices[0])]
        super().__init__(vertices, bordes, es_regular=True)
        self.__ancho = ancho
        self.__alto = alto

    def get_ancho(self):
        return self.__ancho

    def set_ancho(self, ancho):
        self.__ancho = ancho

    def get_alto(self):
        return self.__alto

    def set_alto(self, alto):
        self.__alto = alto

    def calcular_area(self):
        return self.__ancho * self.__alto

    def calcular_angulos_internos(self):
        return [90, 90, 90, 90]

class Cuadrado(Rectangulo):
    def __init__(self, lado):
        super().__init__(lado, lado)

    def get_lado(self):
        return self.get_ancho()

    def set_lado(self, lado):
        self.set_ancho(lado)
        self.set_alto(lado)

    def calcular_angulos_internos(self):
        return [90, 90, 90, 90]

if __name__ == "__main__":
    figuras = [ Isosceles(4, 5), Equilatero(3), Escaleno(4, 5), TriRectangulo(4, 5), Rectangulo(4, 6), Cuadrado(4) ]
    for figura in figuras: 
        print(f"Los ángulos internos de {figura.__class__.__name__} son {figura.calcular_angulos_internos()}")
        print(f"El área de {figura.__class__.__name__} es {figura.calcular_area()}")