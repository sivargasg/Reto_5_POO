from .figuras import Punto, Linea, Figura, Triangulo, Isosceles, Equilatero, Escaleno, TriRectangulo, Rectangulo, Cuadrado

